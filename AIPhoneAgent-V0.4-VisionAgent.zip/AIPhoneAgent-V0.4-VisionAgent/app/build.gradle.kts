plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.aiphoneagent"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.aiphoneagent"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
