
package com.example.aiphoneagent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object AgentBrain {
    private val executor = Executors.newSingleThreadExecutor()

    fun run(context: Context, userText: String, report: (String) -> Unit) {
        executor.execute {
            try {
                val prefs = context.getSharedPreferences("agent", Context.MODE_PRIVATE)
                val apiUrl = prefs.getString("url", "").orEmpty()
                val apiKey = prefs.getString("key", "").orEmpty()
                val model = prefs.getString("model", "gpt-5.6-luna").orEmpty()

                if (apiUrl.isBlank() || apiKey.isBlank()) {
                    localFallback(context, userText, report)
                    return@execute
                }

                // Agent loop: observe -> plan one action -> execute -> observe again.
                repeat(12) { step ->
                    val screenshot = ScreenCaptureService.latestJpeg()
                    val tree = AgentAccessibilityService.instance?.screenSummary().orEmpty()

                    report("أشاهد الشاشة... خطوة ${step + 1}/12")
                    val commands = askVisionAgent(apiUrl, apiKey, model, userText, tree, screenshot)

                    if (commands.length() == 0) {
                        report("لم أجد خطوة آمنة للتنفيذ")
                        return@execute
                    }

                    val action = commands.optJSONObject(0) ?: return@execute
                    val type = action.optString("action")
                    if (type == "DONE") {
                        report(action.optString("message", "تم"))
                        return@execute
                    }

                    executeOne(context, action, report)
                    Thread.sleep(650)
                }

                report("وصلت للحد الآمن من خطوات التنفيذ")
            } catch (_: Throwable) {
                report("حدث خطأ أثناء تشغيل الوكيل")
            }
        }
    }

    private fun askVisionAgent(
        apiUrl: String,
        apiKey: String,
        model: String,
        goal: String,
        tree: String,
        screenshot: ByteArray?
    ): JSONArray {
        val instruction = """
            أنت وكيل Android بصري. نفذ هدف المستخدم على الهاتف خطوة واحدة فقط في كل مرة.
            لا تنفذ حذف ملفات، شراء، تحويل أموال، إرسال رسالة، نشر محتوى، أو تغيير إعداد أمني بدون طلب تأكيد واضح من المستخدم.
            استخدم الصورة إن وجدت لتحديد مكان العنصر، واستخدم شجرة Accessibility كإشارة إضافية.
            أعد JSON array واحدًا فقط.
            الأفعال:
            TAP(x,y), LONG_PRESS(x,y), SWIPE(x1,y1,x2,y2,durationMs),
            CLICK_TEXT(text), TYPE_TEXT(text), BACK, HOME, OPEN_APP(package), DONE(message).
            الإحداثيات هي بكسل من أعلى يسار الشاشة.
            هدف المستخدم: $goal
            شجرة العناصر:
            $tree
        """.trimIndent()

        val content = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", instruction))

        if (screenshot != null) {
            val b64 = Base64.encodeToString(screenshot, Base64.NO_WRAP)
            content.put(
                JSONObject()
                    .put("type", "input_image")
                    .put("image_url", "data:image/jpeg;base64,$b64")
            )
        }

        val payload = JSONObject()
            .put("model", model)
            .put("input", JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("content", content)
            ))

        val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20000
            readTimeout = 45000
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }

        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

        val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
        val text = extractOutputText(body)
        val start = text.indexOf('[')
        val end = text.lastIndexOf(']')
        return if (start >= 0 && end > start) JSONArray(text.substring(start, end + 1))
        else JSONArray()
    }

    private fun extractOutputText(body: String): String {
        val root = JSONObject(body)
        val direct = root.optString("output_text", "")
        if (direct.isNotBlank()) return direct

        val output = root.optJSONArray("output") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val t = c.optString("text", "")
                if (t.isNotBlank()) sb.append(t)
            }
        }
        return sb.toString()
    }

    private fun executeOne(context: Context, action: JSONObject, report: (String) -> Unit) {
        when (action.optString("action")) {
            "TAP" -> AgentAccessibilityService.instance?.tap(
                action.optInt("x"), action.optInt("y")
            )
            "LONG_PRESS" -> AgentAccessibilityService.instance?.longPress(
                action.optInt("x"), action.optInt("y")
            )
            "SWIPE" -> AgentAccessibilityService.instance?.swipe(
                action.optInt("x1"), action.optInt("y1"),
                action.optInt("x2"), action.optInt("y2"),
                action.optLong("durationMs", 500)
            )
            "CLICK_TEXT" -> AgentAccessibilityService.instance?.clickText(action.optString("text"))
            "TYPE_TEXT" -> AgentAccessibilityService.instance?.typeText(action.optString("text"))
            "BACK" -> AgentAccessibilityService.instance?.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
            )
            "HOME" -> AgentAccessibilityService.instance?.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
            )
            "OPEN_APP" -> {
                val pkg = action.optString("package")
                val i = context.packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(i)
                }
            }
        }
        report("نفذت: ${action.optString("action")}")
    }

    private fun localFallback(context: Context, text: String, report: (String) -> Unit) {
        val c = text.lowercase()
        when {
            c.contains("إعدادات") || c.contains("اعدادات") -> {
                context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                report("تم فتح الإعدادات")
            }
            c.contains("يوتيوب") || c.contains("youtube") -> {
                val i = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                report("تم فتح YouTube")
            }
            else -> report("أضف API من الإعدادات لتفعيل الوكيل البصري")
        }
    }
}
