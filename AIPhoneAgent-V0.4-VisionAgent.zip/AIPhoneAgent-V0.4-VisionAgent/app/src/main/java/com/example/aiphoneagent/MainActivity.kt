package com.example.aiphoneagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var glow: SiriGlowView
    private lateinit var status: TextView
    private lateinit var commandText: TextView
    private var recognizer: SpeechRecognizer? = null
    private val captureRequest = 901

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 20)
        }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF07070A.toInt()) }
        glow = SiriGlowView(this)
        root.addView(glow, FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
        }
        val top = FrameLayout(this)
        val title = TextView(this).apply {
            text = "AI PHONE AGENT"
            textSize = 14f
            letterSpacing = 0.18f
            setTextColor(0xFFEDEDF2.toInt())
            gravity = Gravity.CENTER
        }
        top.addView(title, FrameLayout.LayoutParams(-1, 64))
        val gear = TextView(this).apply {
            text = "⚙"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        top.addView(gear, FrameLayout.LayoutParams(72, 64, Gravity.END))
        status = TextView(this).apply {
            text = "جاهز — تحكم كامل بالشاشة"
            textSize = 17f
            setTextColor(0xFFB9B9C7.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 10)
        }
        commandText = TextView(this).apply {
            text = "اضغط وتكلم"
            textSize = 27f
            setTextColor(0xFFF7F7FA.toInt())
            gravity = Gravity.CENTER
            setPadding(14, 24, 14, 14)
        }
        val spacer = View(this)
        content.addView(top)
        content.addView(status)
        content.addView(commandText)
        content.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val mic = Button(this).apply {
            text = "🎙️  تحدث — نفّذ"
            textSize = 18f
            setOnClickListener { listen() }
        }
        content.addView(mic, LinearLayout.LayoutParams(-1, 68))
        val capture = TextView(this).apply {
            text = "👁 تفعيل رؤية الشاشة"
            textSize = 14f
            setTextColor(0xFFAEB3FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 8)
            setOnClickListener {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
            }
        }

        val access = TextView(this).apply {
            text = "♿ تفعيل التحكم الكامل بالشاشة"
            textSize = 14f
            setTextColor(0xFFAEB3FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 8)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        content.addView(capture)
        content.addView(access)
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "التعرف الصوتي غير متاح"
            return
        }
        glow.setListening(true)
        status.text = "أستمع..."
        commandText.text = "تكلم الآن"
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : SimpleRecognitionListener() {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                glow.setListening(false)
                commandText.text = text.ifBlank { "لم أسمع شيئًا" }
                if (text.isBlank()) { status.text = "حاول مرة أخرى"; return }
                status.text = "الوكيل ينفذ على الشاشة..."
                AgentBrain.run(this@MainActivity, text) { message -> runOnUiThread { status.text = message } }
            }
            override fun onError(error: Int) {
                glow.setListening(false)
                status.text = "تعذر فهم الصوت"
                commandText.text = "حاول مرة أخرى"
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "ماذا تريد أن أفعل؟")
        }
        recognizer?.startListening(intent)
    }

    override fun onDestroy() { recognizer?.destroy(); super.onDestroy() }
}


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(intent)
            status.text = "رؤية الشاشة مفعّلة"
        }
    }
