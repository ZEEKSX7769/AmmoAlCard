package com.example.aiphoneagent

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class SiriGlowView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var listening = false

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        postInvalidateOnAnimation()
    }

    fun setListening(value: Boolean) {
        listening = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // Soft bottom "Siri-like" light field.
        val cy = h * if (listening) 0.71f else 0.78f
        val cx = w * 0.5f

        val pulse = (sin(phase.toDouble()).toFloat() + 1f) * 0.5f
        val radius = w * (0.25f + pulse * if (listening) 0.05f else 0.015f)

        drawGlow(canvas, cx - w * 0.14f, cy, radius * 0.72f, 0x554F7BFF)
        drawGlow(canvas, cx + w * 0.12f, cy - 12f, radius * 0.64f, 0x5547E8FF)
        drawGlow(canvas, cx, cy + 12f, radius, 0x553B5BFF)

        // Central luminous orb.
        val orbRadius = w * if (listening) 0.085f else 0.075f
        val orb = RadialGradient(
            cx, cy, orbRadius,
            intArrayOf(0xFFF7F7FF.toInt(), 0xFFB6D8FF.toInt(), 0xFF6A55FF.toInt(), 0x002A255F),
            floatArrayOf(0f, 0.23f, 0.68f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.shader = orb
        canvas.drawCircle(cx, cy, orbRadius * 2.2f, paint)
        paint.shader = null

        // Flowing light ribbons.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        paint.alpha = 150
        repeat(4) { i ->
            val path = Path()
            val y = cy - 80f + i * 34f
            path.moveTo(-40f, y)
            val sway = sin((phase + i * 0.8f).toDouble()).toFloat() * 55f
            path.cubicTo(w * 0.20f, y - sway, w * 0.34f, y + sway,
                cx, y + sway * 0.3f)
            path.cubicTo(w * 0.66f, y - sway, w * 0.81f, y + sway,
                w + 40f, y)
            canvas.drawPath(path, paint)
        }
        paint.alpha = 255
        paint.style = Paint.Style.FILL

        phase += if (listening) 0.08f else 0.025f
        postInvalidateOnAnimation()
    }

    private fun drawGlow(canvas: Canvas, x: Float, y: Float, r: Float, color: Int) {
        paint.shader = RadialGradient(x, y, r, color, 0x00101018, Shader.TileMode.CLAMP)
        canvas.drawCircle(x, y, r, paint)
        paint.shader = null
    }
}
