package com.example.aiphoneagent

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("agent", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }

        val title = TextView(this).apply {
            text = "⚙ إعدادات AI"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        root.addView(title)

        fun field(label: String, value: String, secret: Boolean = false): EditText {
            val box = EditText(this).apply {
                hint = label
                setText(value)
                textSize = 16f
                setSingleLine(true)
                setPadding(18, 6, 18, 6)
                if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            root.addView(box, LinearLayout.LayoutParams(-1, 60).apply { bottomMargin = 14 })
            return box
        }

        val url = field("API URL", prefs.getString("url", "https://api.openai.com/v1/responses") ?: "")
        val key = field("API Key", prefs.getString("key", "") ?: "", true)
        val model = field("Model", prefs.getString("model", "gpt-5-mini") ?: "")

        val note = TextView(this).apply {
            text = "ضع مفتاحك على جهازك فقط. لا ترسل المفتاح داخل المحادثة."
            textSize = 13f
            setPadding(0, 8, 0, 18)
        }
        root.addView(note)

        val save = Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                prefs.edit()
                    .putString("url", url.text.toString().trim())
                    .putString("key", key.text.toString().trim())
                    .putString("model", model.text.toString().trim())
                    .apply()
                Toast.makeText(this@SettingsActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(save, LinearLayout.LayoutParams(-1, 60))

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
