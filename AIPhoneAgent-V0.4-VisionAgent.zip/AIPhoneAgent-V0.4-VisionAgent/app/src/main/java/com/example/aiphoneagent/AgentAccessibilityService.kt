
package com.example.aiphoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

class AgentAccessibilityService : AccessibilityService() {
    companion object {
        var instance: AgentAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun tap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
                .build(), null, null
        )
    }

    fun longPress(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 750))
                .build(), null, null
        )
    }

    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, duration: Long): Boolean {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration.coerceIn(100, 3000)))
                .build(), null, null
        )
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findEditable(root) ?: return false
        return target.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
                )
            }
        )
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findByText(root, text) ?: return false
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.centerX(), r.centerY())
    }

    fun screenSummary(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        appendNode(root, sb, 0)
        return sb.toString().take(12000)
    }

    private fun appendNode(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 7 || sb.length > 12000) return
        val text = node.text?.toString()?.replace("\n", " ").orEmpty()
        val desc = node.contentDescription?.toString()?.replace("\n", " ").orEmpty()
        if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isEditable) {
            val r = Rect()
            node.getBoundsInScreen(r)
            sb.append("node text=").append(text)
                .append(" desc=").append(desc)
                .append(" clickable=").append(node.isClickable)
                .append(" editable=").append(node.isEditable)
                .append(" bounds=").append(r)
                .append("\n")
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { appendNode(it, sb, depth + 1) }
        }
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findEditable(it)?.let { found -> return found } }
        }
        return null
    }

    private fun findByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val label = node.text?.toString().orEmpty()
        val desc = node.contentDescription?.toString().orEmpty()
        if (label.contains(text, true) || desc.contains(text, true)) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findByText(it, text)?.let { found -> return found } }
        }
        return null
    }
}
